package io.getarrays.contactapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileuploadanddownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
